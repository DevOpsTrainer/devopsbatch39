import groovy.json.JsonSlurper 
@groovy.transform.Canonical class job { 
  String folder ='GIT/J2EE', jobName, gitOrg, server ='xcambldm1p.p', taborId = '', gitRepo = '', rootPomSubDir='', recipientList='SrinivasanA@aetna.com', sharedLibrary='aefw_v3.0.1', baseDir, sonatypeApplicationId, mavenCommandLineOpts='', branch='', MAVEN_OPTS='', JAVA_HOME='/aetnas90/build/cam/opt/IBMWebAS855/java_1.7_64', MAVEN_HOME='/aetnas90/build/techen/maven/apache-maven-3.3.9', WAS_HOME='/aetnas90/build/cam/opt/IBMWebAS855'
  Integer sharedJVM=1, disableCodeScan=0, buildOnly=0, isBatch=0, isDataScience=0, omitDeploy=0
} 
def baseDir = '.'
def buildType='Java'

hudson.FilePath workspace = hudson.model.Executor.currentExecutor().getCurrentWorkspace()
def dataFile = "${workspace}/jenkins/groovy.dsl/git/data/J2EE.txt"

new File(dataFile).eachLine{ line ->
  def aJob = job.newInstance(new JsonSlurper().parseText(line))
  def directoryInWorkspace = "${baseDir}/${aJob.jobName}-parent"
  def copyBatchLibs = aJob.isBatch ? '-P copy-batch-libs' : ''
  def gitRepo = aJob.gitRepo ? aJob.gitRepo : aJob.jobName
  def commentOutDeploy = aJob.omitDeploy ? "#" : ""
  branch = aJob.branch ? aJob.branch + ",*/master" : "*/${aJob.jobName}_Path*,*/master"
    String sonarLinkForTable
    if ( ! aJob.disableCodeScan )
    {
      sonarLinkForTable = """  <tr>
    <td><b>Sonar Dashboard URL</b></td>
    <td>\${SONAR_DASHBOARD_PROD}/${aJob.jobName}</td>
    <td>Sonarqube server healthy? -> \${SONAR_HEALTH_CHECK}</td>
  </tr>
"""
    }
  job("${aJob.folder}/${aJob.jobName}") { 
    label(aJob.server)
    quietPeriod(0)
    'jdk' ('default')
    logRotator(-1, 20)
    environmentVariables {
        envs( JNK_JOB_NAME: aJob.jobName)
    }
    configure{
      it / 'properties' << 'com.sonyericsson.jenkins.plugins.bfa.model.ScannerJobProperty'( plugin: 'build-failure-analyzer@1.13.0'){
        doNotScan(false)
      }
    }
    scm{
      git{
        remote{
          url("git@github.aetna.com:${aJob.gitOrg}/${gitRepo}.git")
          credentials('f4953df8-6f5d-4843-a332-c86ff1208f76')
        }
        branch.tokenize(',').each{
          branches(it)
        }
        extensions{cleanAfterCheckout()}
      }
    }
    triggers{ scm('') } 
    steps {
        shell('''//aetnas90/build/cam/Jenkins/scripts/getPath.pl ${GIT_BRANCH} > ./runtime.devops.properties
//aetnas90/build/cam/Jenkins/scripts/pathExtendedProject.pl ${GIT_URL} ${GIT_BRANCH} >> runtime.devops.properties''')
        shell('''STATUS_CODE=$(curl -s -o /dev/null -w '%{http_code}' https://sonarqube.aetna.com/sessions/new)
if [ $STATUS_CODE -eq 200 ]; then
    echo SONAR_HEALTH_CHECK="true" >> env.properties
else
    echo SONAR_HEALTH_CHECK="false" >> env.properties
fi''')
        environmentVariables {
          propertiesFile('${WORKSPACE}/runtime.devops.properties')
        }
        environmentVariables {
          propertiesFile('${WORKSPACE}/env.properties')
        }
        shell("""if [[ ! -f /aetnas90/build/cam/Jenkins/data/GIT/${buildType}/\${DEVOPS_PATH_EXTENDED_PROJECT}.properties ]]; then echo DEVOPS_BRANCH_BUILD_NUMBER=1 > /aetnas90/build/cam/Jenkins/data/GIT/${buildType}/\${DEVOPS_PATH_EXTENDED_PROJECT}.properties; fi""")
        environmentVariables { propertiesFile("/aetnas90/build/cam/Jenkins/data/GIT/${buildType}/\${DEVOPS_PATH_EXTENDED_PROJECT}.properties")
                               env('UCD_SNAPSHOT', '${DEVOPS_PATH_EXTENDED_PROJECT}_${DEVOPS_BRANCH_BUILD_NUMBER}') 
        }
        shell("""cd ${directoryInWorkspace}
mvn clean org.jacoco:jacoco-maven-plugin:0.7.4.201502262128:prepare-agent install deploy ${copyBatchLibs} ${aJob.mavenCommandLineOpts}""")
        conditionalSteps {
            condition {
                booleanCondition ('${ENV,var="SONAR_HEALTH_CHECK"}')
            }
            runner('Run')
        }
    }
    configure { 
        it / 'builders' / 'org.jenkinsci.plugins.conditionalbuildstep.ConditionalBuilder' / 'conditionalbuilders' << 'hudson.plugins.sonar.SonarRunnerBuilder'(plugin: 'sonar@2.2.1'){
            project()
            installationName("SonarQubeProd")
            sonarScannerName("Sonar_Runner_Build_Server")
            properties("""sonar.projectKey=${aJob.jobName}
sonar.projectName=${aJob.jobName}  
sonar.projectVersion=\$BUILD_NUMBER
sonar.language=java
sonar.sources=.
sonar.sourceEncoding=UTF-8
sonar.login=\${SONARQUBE_SCANNER_TOKEN}""")
            javaOpts()
            delegate.jdk('RedHat Package 1.8')
            task()
        }
    }
    if ( aJob.sharedJVM && ! aJob.isBatch )
    {
      steps {
        shell("""if [[ "\${DEVOPS_PATH}" ]]
then
//aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/changeContextRoot.pl -p "\${DEVOPS_PATH}" -e ${aJob.jobName} \${WORKSPACE}/${directoryInWorkspace}/../${aJob.jobName}-ear/target 
fi""")
      }
    }
    if ( aJob.jobName == 'AEFWDiag305')
    {
//    configure{
//      it / builders << 'com.checkmarx.jenkins.CxScanBuilder'( plugin: 'checkmarx@8.0.1'){
//        projectName(aJob.jobName)
//        waitForResultsEnabled(false)
//        fullScansScheduled(false)
//        useOwnServerCredentials(false)
//        serverUrl('https://checkmarxint.aetna.com')
//      }
//    }
    }
    wrappers {
        timestamps()
        maskPasswords()
        environmentVariables {
            envs(JAVA_HOME: aJob.JAVA_HOME, MAVEN_HOME: aJob.MAVEN_HOME, WAS_HOME: aJob.WAS_HOME, PATH: '/mntpvcs/pvcsu04/vm/linux/bin:/mntpvcs/pvcsu04/vm/common/bin/linux:/usr/kerberos/bin:/usr/local/bin:/bin:/usr/bin:/opt/quest/bin:/bin:/usr/bin:/usr/X11R6/bin:/usr/sbin:/usr/local/bin:/opt/rational/clearcase/bin:/opt/rational/clearcase/etc:/opt/rational/clearcase/etc/utils:/opt/rational/common/bin:/aetnas05/ccase/adm01/util/bin:.:/usr/local/sbin:${JAVA_HOME}/bin:/aetnas90/build/techen/maven/apache-maven-3.0.4/bin:/opt/rational/clearcase/bin:${MAVEN_HOME}/bin',MAVEN_OPTS: aJob.MAVEN_OPTS)
        }
    }
    publishers{
        postBuildScripts {
            steps {
                shell("""echo DEVOPS_BRANCH_BUILD_NUMBER=\$(( \$DEVOPS_BRANCH_BUILD_NUMBER + 1)) > /aetnas90/build/cam/Jenkins/data/GIT/${buildType}/\${DEVOPS_PATH_EXTENDED_PROJECT}.properties""")
            if ( ! aJob.buildOnly )
            {
              shell("""export UCD_PATH_VERSION_PROPERTY="--version-property-item envPath=\${DEVOPS_PATH} "
/aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/uploadToUdeploy.pl --user s060758 --password "\$s060758" --component ${aJob.jobName} --version \${JNK_JOB_NAME}_\${BUILD_NUMBER} --snapshot \${UCD_SNAPSHOT} --include '**/*' --exclude '**/*.java' --exclude '**/.git/**' --application ${aJob.jobName} --quiet --version-property-item appName=${aJob.jobName} --version-property-item sharedJVM=${aJob.sharedJVM} --version-property-item sharedLibrary=${aJob.sharedLibrary}""" + ( aJob.taborId ? " --version-property-item taborId=${aJob.taborId}" : '' ) + """ \${UCD_PATH_VERSION_PROPERTY} --version-property-item BUILD_TIMESTAMP=\$BUILD_TIMESTAMP --version-property-item Build_URL=\${BUILD_URL} --version-property-item BUILD_NUMBER=\$BUILD_NUMBER \$WORKSPACE/${baseDir}
${commentOutDeploy}/aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/runUdeployApplicationProcess.pl --user s060758 --password "\$s060758" --snapshot \${UCD_SNAPSHOT} --application ${aJob.jobName} --application-process 'Deploy ${aJob.jobName}' --environment DEV\${DEVOPS_PATH}""")
           }
         }
        }
    }
      if ( ! aJob.disableCodeScan )
//      if ('')
    {
        configure {
          it / delegate.publishers << 'com.sonatype.insight.ci.hudson.PostBuildScan' (plugin:'sonatype-clm-ci@2.10.0-02') {
            failOnSecurityAlerts(false)
            pathConfig('')
            applicationSelectType{
              value('list')
              applicationId(aJob.sonatypeApplicationId)
            }
          }
        }
    }
    publishers {

String emailContent="""<!DOCTYPE html>
<html>
<body>
<p>Dear User,</p>

<p>Please review the following build details.</p>
<table style="width:100%">

<table border="1" bgcolor="#EFFBFB">

  <tr>
    <td><b>Job Name</b></td>
    <td>\$JNK_JOB_NAME</td>    
  </tr>
  <tr>
    <td><b>Git repository URL</b></td>
    <td>\$GIT_URL</td>    
  </tr>
  <tr>
    <td><b>Git branch</b></td>
    <td>\$GIT_BRANCH</td>    
  </tr>
  <tr>
    <td><b>Committed by</b></td>
    <td>\${CHANGES,format="%a"}</td>    
  </tr>
  <tr>
    <td><b>Commit ID</b></td>
    <td>\${CHANGES,format="%r"}</td>    
  </tr>
  <tr>
    <td><b>Changes</b></td>
    <td>\${CHANGES,showPaths=true,format="%p"}</td>    
  </tr>
  <tr>
    <td><b>Commit Message</b></td>
    <td>\${CHANGES,format="&#8220;<em>%m</em>&#8221"}</td>    
  </tr>
  <tr>
    <td><b>Build Number</b></td>
    <td>\$BUILD_NUMBER</td>    
  </tr>
  <tr>
    <td><b>Build Date & Time<b></td>
    <td>\$BUILD_TIMESTAMP</td>    
  </tr>
  <tr>
    <td><b>Build Status</b></td>
    <td>\$BUILD_STATUS</td>    
  </tr>
  <tr>
    <td><b>Build URL</b></td>
    <td>\$BUILD_URL</td>    
  </tr>
${sonarLinkForTable}  
</table>

<BR>
<b>Thanks,<BR>
<BR>
DevOps @ Aetna<BR></b>
</body>
</html>
"""
      extendedEmail {
          recipientList(aJob.recipientList)
          defaultSubject('Build Report for ${DEVOPS_PATH_EXTENDED_PROJECT} - Build # ${DEVOPS_BRANCH_BUILD_NUMBER} - $BUILD_STATUS!')
          contentType('text/html')
          saveToWorkspace()
          defaultContent(emailContent)
            triggers {
               success {
                  sendTo {
                      recipientList()
                  }
              }
               failure {
                  subject('**FAILED BUILD**  for ${DEVOPS_PATH_EXTENDED_PROJECT} - Build # ${DEVOPS_BRANCH_BUILD_NUMBER} - $BUILD_STATUS!')
                  sendTo {
                      recipientList()
                  }
              }
               aborted {
                  subject('**ABORTED BUILD**  for ${DEVOPS_PATH_EXTENDED_PROJECT} - Build # ${DEVOPS_BRANCH_BUILD_NUMBER} - $BUILD_STATUS!')
                  sendTo {
                      recipientList()
                  }
              }
         }
      }
    } 
 }
}
