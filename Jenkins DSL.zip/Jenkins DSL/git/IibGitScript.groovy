import groovy.json.JsonSlurper 
Set<String> madeDirs = new HashSet<String>()
@groovy.transform.Canonical class job { 
  String folder = '/GIT/IIB', jobName,  gitOrg, server = 'xcamjbem1p.p1', recipientList, buildXml = 'build_devops.xml', disableSonarqube, IIB_VERSION
}

def jobList = []
hudson.FilePath workspace = hudson.model.Executor.currentExecutor().getCurrentWorkspace()
def dataFile = "${workspace}/jenkins/groovy.dsl/git/data/IIB.txt"
println("Data file is: ${dataFile}")
new File(dataFile).eachLine{ line ->
    jobList << line
}

defaultEmail='cc:EIEDTDevOpsSupport@AETNA.com,cc:HuttonJ@aetna.com'

def buildType='IIB'

jobList.each { item ->
def aJob = job.newInstance(new JsonSlurper().parseText(item))
String sonarLinkForTable, deployViaCurl
String emailList = aJob.recipientList ? "${aJob.recipientList},${defaultEmail}" : defaultEmail
String gitRepo =  "git@github.aetna.com:${aJob.gitOrg}/${aJob.jobName}.git"
if ( aJob.IIB_VERSION == "10" ){
    deployViaCurl = """curl -k "https://ci.aetna.com/jenkins/job/GIT/job/IIB/job/_Deploy_IIB/job/\${DEVOPS_DOWNSTREAM_JOB}/buildWithParameters?token=Q0FNX0tJQ0tPRkY=&UCD_Application=${aJob.jobName}&UCD_Application_Process=Deploy_IIB_App&UCD_Environment=DEV\${DEVOPS_PATH}&UCD_SnapShot=\${UCD_SNAPSHOT}&GIT_COMMIT=\${GIT_COMMIT}&GIT_URL=\${GIT_URL}&GIT_BRANCH=\${GIT_BRANCH}&JNK_ORIGINAL_BUILD_URL=\$BUILD_URL&UCD_RECIPIENTS=${emailList}&delay=0" """
} else {
    deployViaCurl = """curl -k "https://ci.aetna.com/jenkins/job/GIT/job/IIB/job/_Deploy_IIB/job/\${DEVOPS_DOWNSTREAM_JOB}/buildWithParameters?token=Q0FNX0tJQ0tPRkY=&UCD_Application=${aJob.jobName}&UCD_Application_Process=Deploy_${aJob.jobName}v10&UCD_Environment=DEV\${DEVOPS_PATH}&UCD_SnapShot=\${UCD_SNAPSHOT}&GIT_COMMIT=\${GIT_COMMIT}&GIT_URL=\${GIT_URL}&GIT_BRANCH=\${GIT_BRANCH}&JNK_ORIGINAL_BUILD_URL=\$BUILD_URL&UCD_RECIPIENTS=${emailList}&delay=0" """
}
if ( ! aJob.disableSonarqube )
    {
      sonarLinkForTable = '''  <tr>
    <td><b>Sonar Dashboard URL</b></td>
    <td>${SONAR_DASHBOARD_PROD}/${DEVOPS_PATH_EXTENDED_PROJECT}</td>
    <td>Sonarqube server healthy? -> \${SONAR_HEALTH_CHECK}</td>
  </tr>
'''
    }
String emailSuccessContent="""<!DOCTYPE html>
<html>
<body>


<p>Dear User,</p>

<p>Please review the following build details.</p>
<table style="width:100%">

<table border="1" bgcolor="#EFFBFB">

  <tr>
    <td><b>Job Name</b></td>
    <td>\$JOB_NAME</td>    
  </tr>
  <tr>
    <td><b>Git repository URL</b></td>
    <td>\$GIT_URL</td>    
  </tr>
  <tr>
    <td><b>Git branch</b></td>
    <td>\$GIT_BRANCH</td>    
  </tr>
  <tr>
    <td><b>Committed by</b></td>
    <td>\${CHANGES,format="%a"}</td>    
  </tr>
  <tr>
    <td><b>Commit ID</b></td>
    <td>\${CHANGES,format="%r"}</td>    
  </tr>
  <tr>
    <td><b>Changes</b></td>
    <td>\${CHANGES,showPaths=true,format="%p"}</td>    
  </tr>
  <tr>
    <td><b>Commit Message</b></td>
    <td>\${CHANGES,format="&#8220;<em>%m</em>&#8221"}</td>    
  </tr>
  <tr>
    <td><b>Build Number</b></td>
    <td>\$BUILD_NUMBER</td>    
  </tr>
    <tr>
    <td><b>Project</b></td>
    <td>${aJob.jobName}</td>    
  </tr>
  <tr>
    <td><b>Build Date & Time<b></td>
    <td>\$BUILD_TIMESTAMP</td>    
  </tr>
  <tr>
    <td><b>Build Status</b></td>
    <td>\$BUILD_STATUS</td>    
  </tr>
  <tr>
    <td><b>Build URL</b></td>
    <td>\$BUILD_URL</td>    
  </tr>
${sonarLinkForTable}  
</table>

<p>Please find attached logs for more details. </p>
<BR>
<BR>
<b>Thanks,<BR>
<BR>
DevOps @ Aetna<BR></b>
</body>
</html>
"""
  job("${aJob.folder}/${aJob.jobName}") { 
    description("""Made by Job DSL plugin.
Do not edit by hand.
Made by jenkins/groovy.dsl/git/IibGitScript.groovy""")
    logRotator(-1, 20)
    parameters {
      stringParam('BRANCH', "origin/${aJob.jobName}_Path*", 'Clear the value if promoting manually and input the name of the branch to build.')
    }
    configure{
      it / 'properties' << 'com.sonyericsson.jenkins.plugins.bfa.model.ScannerJobProperty'( plugin: 'build-failure-analyzer@1.13.0'){
        doNotScan(false)
      }
    }
    'jdk' ('(Default)')
    label(aJob.server)
    quietPeriod(0)
    scm{
      git{
        remote{
          url("git@github.aetna.com:${aJob.gitOrg}/${aJob.jobName}.git")
          credentials('f4953df8-6f5d-4843-a332-c86ff1208f76')
        }

        branches('${BRANCH}')
        extensions{cleanAfterCheckout()}
      }
    }
    triggers{ scm('') }
    
    steps {
        shell('''//aetnas90/build/cam/Jenkins/scripts/getPath.pl $GIT_BRANCH > ./runtime.devops.properties
//aetnas90/build/cam/Jenkins/scripts/pathExtendedProject.pl ${GIT_URL} ${GIT_BRANCH} >> ./runtime.devops.properties
for f in ${WORKSPACE}/*_devops_test_project*.xml; do test -f "$f" && DEVOPS_IS_SOAPUI=1 && break; done; echo DEVOPS_IS_SOAPUI=$DEVOPS_IS_SOAPUI >> ./runtime.devops.properties
if [ $DEVOPS_IS_SOAPUI ]; then echo DEVOPS_DOWNSTREAM_JOB=IIB_Dev_Deploy_SoapUI; else echo DEVOPS_DOWNSTREAM_JOB=IIB_Dev_Deploy; fi >> ./runtime.devops.properties''')
        shell('''STATUS_CODE=$(curl -s -o /dev/null -w '%{http_code}' https://sonarqube.aetna.com/sessions/new)
if [ $STATUS_CODE -eq 200 ]; then
    echo SONAR_HEALTH_CHECK="true" >> runtime.devops.properties
else
    echo SONAR_HEALTH_CHECK="false" >> runtime.devops.properties
fi''')
        environmentVariables {
          propertiesFile('${WORKSPACE}/runtime.devops.properties')
    }
    shell('''//aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/IIB_build.pl ${WORKSPACE}''')
        environmentVariables {
          propertiesFile('${WORKSPACE}/JNK.properties')
    }
        shell("""if [[ ! -f /aetnas90/build/cam/Jenkins/data/GIT/${buildType}/\${DEVOPS_PATH_EXTENDED_PROJECT}.properties ]]; then echo DEVOPS_BRANCH_BUILD_NUMBER=1 > /aetnas90/build/cam/Jenkins/data/GIT/${buildType}/\${DEVOPS_PATH_EXTENDED_PROJECT}.properties; fi""")
        shell('''if [[ ! -f ${WORKSPACE}/build_devops.xml ]] 
then
  if [[ -f ${WORKSPACE}/build_devops${DEVOPS_LOGICAL_PATH}.xml ]]; then cp ${WORKSPACE}/build_devops${DEVOPS_LOGICAL_PATH}.xml ${WORKSPACE}/build_devops.xml
  fi
fi''')
        environmentVariables { propertiesFile("/aetnas90/build/cam/Jenkins/data/GIT/${buildType}/\${DEVOPS_PATH_EXTENDED_PROJECT}.properties")
                               env('UCD_SNAPSHOT', '${DEVOPS_PATH_EXTENDED_PROJECT}_${DEVOPS_BRANCH_BUILD_NUMBER}') 
        }
      ant{
        target('')
        buildFile(aJob.buildXml)
      }
      shell('echo SONARKEY=${DEVOPS_PATH_EXTENDED_PROJECT}>env.properties')
      if ( ! aJob.disableSonarqube ) {
        conditionalSteps {
                condition {
                    booleanCondition ('${ENV,var="SONAR_HEALTH_CHECK"}')
                }
                runner('Run')
        }
      }
    }
    if ( ! aJob.disableSonarqube ) {
        configure { 
            it / 'builders' / 'org.jenkinsci.plugins.conditionalbuildstep.ConditionalBuilder' / 'conditionalbuilders' << 'hudson.plugins.sonar.SonarRunnerBuilder'(plugin: 'sonar@2.2.1'){
                project()
                installationName("SonarQubeProd")
                sonarScannerName("Sonar_Runner_Build_Server")
                properties('''sonar.projectKey=${DEVOPS_PATH_EXTENDED_PROJECT}
    sonar.projectName=${DEVOPS_PATH_EXTENDED_PROJECT}  
    sonar.projectVersion=$BUILD_NUMBER
    sonar.sources=.
    sonar.sourceEncoding=UTF-8
    sonar.language=mqmb
    sonar.login=${SONARQUBE_SCANNER_TOKEN}''')
                javaOpts()
                delegate.jdk('RedHat Package 1.8')
                task()
            }
        }
    }
    publishers{
      archiveArtifacts{
          pattern('dist/*.bar')
          pattern('*_devops_test_project.xml')
          pattern('build.DEV.properties')
          pattern('*.xls')
          allowEmpty(false)
          onlyIfSuccessful(false)
          fingerprint(false)
      }
      extendedEmail {
          recipientList(emailList)
          defaultSubject('Build Report for ${DEVOPS_PATH_EXTENDED_PROJECT} - Build # ${DEVOPS_BRANCH_BUILD_NUMBER} - $BUILD_STATUS!')
          contentType('text/html')
          saveToWorkspace()
          defaultContent(emailSuccessContent)
            triggers {
               success {
                  attachBuildLog()
                  attachmentPatterns('**/*_trace.txt')
                  compressBuildLog()
                  sendTo {
                      recipientList()
                  }
              }
               failure {
                  attachBuildLog()
                  attachmentPatterns('**/*_trace.txt')
                  compressBuildLog()
                  subject('**FAILED BUILD**  for ${DEVOPS_PATH_EXTENDED_PROJECT} - Build # ${DEVOPS_BRANCH_BUILD_NUMBER} - $BUILD_STATUS!')
                  sendTo {
                      recipientList()
                  }
              }
               aborted {
                  attachBuildLog()
                  compressBuildLog()
                  subject('**ABORTED BUILD**  for ${DEVOPS_PATH_EXTENDED_PROJECT} - Build # ${DEVOPS_BRANCH_BUILD_NUMBER} - $BUILD_STATUS!')
                  sendTo {
                      recipientList()
                  }
              }
         }
      }
        postBuildScripts {
            steps {
                shell("""echo DEVOPS_BRANCH_BUILD_NUMBER=\$(( \$DEVOPS_BRANCH_BUILD_NUMBER + 1)) > /aetnas90/build/cam/Jenkins/data/GIT/${buildType}/\${DEVOPS_PATH_EXTENDED_PROJECT}.properties
/aetnas90/build/cam/Jenkins/scripts/uploadToUdeploy.pl --user s060758 --password "\$s060758" --component ${aJob.jobName} --version ${aJob.jobName}_\$BUILD_NUMBER --snapshot \${UCD_SNAPSHOT} --include '*.properties' --include 'dist/*.bar' --exclude 'build.*.properties' --exclude 'exec_group.properties' --exclude 'runtime.devops.properties' --quiet --application ${aJob.jobName} --version-properties \$WORKSPACE/exec_group.properties \$WORKSPACE
$deployViaCurl
""")
            }
          markBuildUnstable(false)
          onlyIfBuildFails(false)
          onlyIfBuildSucceeds(true)
        }
//        downstreamParameterized {
//            trigger('_Deploy_IIB/IIB_Dev_Deploy') {
//                condition('UNSTABLE_OR_BETTER')
//                parameters {
//                    predefinedProp('UCD_Application', aJob.jobName)
//                    predefinedProp('UCD_Application_Process', 'Deploy_IIB_App')
//                    predefinedProp('UCD_Environment', 'DEV${DEVOPS_PATH}')
//                    predefinedProp('UCD_SnapShot', '${UCD_SNAPSHOT}')
//                    predefinedProp('GIT_COMMIT', '${GIT_COMMIT}')
//                    predefinedProp('GIT_URL', '${GIT_URL}')
//                    predefinedProp('GIT_BRANCH', '${GIT_BRANCH}')
//                    predefinedProp('JNK_ORIGINAL_BUILD_URL', '$BUILD_URL')
//                    predefinedProp('UCD_RECIPIENTS', emailList)
//                    predefinedProp('delay', '0')
//                }
//            }
//        }
    }
    wrappers {
      timestamps()
      maskPasswords()
      preBuildCleanup()
      xvfb('xcamjbem1p') {
            assignedLabels(aJob.server)
            debug(true)
      }
      injectPasswords{
         injectGlobalPasswords(true)
         maskPasswordParameters(true)
        
      }
    }
  }
}
