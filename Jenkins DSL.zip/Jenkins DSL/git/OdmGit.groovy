import groovy.json.JsonSlurper 
String defaultEmail = 'cc:EIEDTDevOpsSupport@AETNA.com,cc:HuttonJ@aetna.com'
@groovy.transform.Canonical class job { 
  String jobName, folder ='/GIT/ODM', server ='wvdi-vmws49303', gitOrg, recipientList='', disableSonarqube
} 
hudson.FilePath workspace = hudson.model.Executor.currentExecutor().getCurrentWorkspace()
def buildType='ODM'
def dataFile = "${workspace}/jenkins/groovy.dsl/git/data/${buildType}.txt"
println("Data file is: ${dataFile}")
new File(dataFile).eachLine{ line ->
def aJob = job.newInstance(new JsonSlurper().parseText(line))
  println "Making job: ${aJob.folder}/${aJob.jobName}"
  String nameLessOdm=(aJob.jobName).replaceAll(/_ODM/, "")
  String emailList = aJob.recipientList ? "${aJob.recipientList},${defaultEmail}" : defaultEmail
    String sonarLinkForTable
    if ( ! aJob.disableSonarqube )
    {
      sonarLinkForTable = '''  <tr>
    <td><b>Sonar Dashboard URL</b></td>
    <td>${SONAR_DASHBOARD_PROD}/${DEVOPS_PATH_EXTENDED_PROJECT}</td>
    <td>Sonarqube server healthy? -> ${SONAR_HEALTH_CHECK}</td>
  </tr>'''
    }
    
    String emailSuccessContent="""<!DOCTYPE html>
<html>
<body>


<p>Dear User,</p>

<p>Please find the build details</p>
<table style="width:100%">

<table border="1" bgcolor="#EFFBFB">

  <tr>
    <td><b>Job Name</b></td>
    <td>\$JOB_NAME</td>    
  </tr>
  <tr>
    <td><b>Build Number</b></td>
    <td>\$BUILD_NUMBER</td>    
  </tr>
  <tr>
    <td><b>Git repository URL</b></td>
    <td>\$GIT_URL</td>    
  </tr>
  <tr>
    <td><b>Git branch</b></td>
    <td>\$GIT_BRANCH</td>    
  </tr>
  <tr>
    <td><b>Committed by</b></td>
    <td>\${CHANGES,format="%a"}</td>    
  </tr>
  <tr>
    <td><b>Commit ID</b></td>
    <td>\${CHANGES,format="%r"}</td>    
  </tr>
  <tr>
    <td><b>Changes</b></td>
    <td>\${CHANGES,showPaths=true,format="%p"}</td>    
  </tr>
  <tr>
    <td><b>Commit Message</b></td>
    <td>\${CHANGES,format="&#8220;<em>%m</em>&#8221"}</td>    
  </tr>
  <tr>
    <td><b>Build Date & Time<b></td>
    <td>\$BUILD_TIMESTAMP</td>    
  </tr>
  <tr>
    <td><b>Build Status</b></td>
    <td>\$BUILD_STATUS</td>    
  </tr>
  <tr>
    <td><b>Build URL</b></td>
    <td>\$BUILD_URL</td>    
  </tr>
${sonarLinkForTable}  
</table>

<p>Please find attached logs for more details. </p>
<BR>
<BR>
<b>Thanks,<BR>
<BR>
DevOps @ Aetna<BR></b>
</body>
</html>
"""

    String emailFailureContent="""<!DOCTYPE html>
<html>
<body>


<p>Dear User,</p>

<p>Please find the build details</p>
<table style="width:100%">

<table border="1" bgcolor="#EFFBFB">

  <tr>
    <td><b>Job Name</b></td>
    <td>\$JOB_NAME</td>    
  </tr>
  <tr>
    <td><b>Build Number</b></td>
    <td>\$BUILD_NUMBER</td>    
  </tr>
  <tr>
    <td><b>Git repository URL</b></td>
    <td>\$GIT_URL</td>    
  </tr>
  <tr>
    <td><b>Git branch</b></td>
    <td>\$GIT_BRANCH</td>    
  </tr>
  <tr>
    <td><b>Committed by</b></td>
    <td>\${CHANGES,format="%a"}</td>    
  </tr>
  <tr>
    <td><b>Commit ID</b></td>
    <td>\${CHANGES,format="%r"}</td>    
  </tr>
  <tr>
    <td><b>Changes</b></td>
    <td>\${CHANGES,showPaths=true,format="%p"}</td>    
  </tr>
  <tr>
    <td><b>Commit Message</b></td>
    <td>\${CHANGES,format="&#8220;<em>%m</em>&#8221"}</td>    
  </tr>
  <tr>
    <td><b>Build Date & Time<b></td>
    <td>\$BUILD_TIMESTAMP</td>    
  </tr>
  <tr>
    <td><b>Build Status</b></td>
    <td>\$BUILD_STATUS</td>    
  </tr>
  <tr>
    <td><b>Build URL</b></td>
    <td>\$BUILD_URL</td>    
  </tr>
${sonarLinkForTable}  
</table>


<p>Please find attached logs for more details. </p>
<BR>
Thanks,<BR>
<BR>
<b>DevOps @ Aetna<BR></b>
</body>
</html>"""


  job("${aJob.folder}/${aJob.jobName}") { 
    description('Made by Job DSL plugin.  Do not edit by hand.')
    logRotator(-1, 20)
    configure{
      it / 'properties' << 'com.sonyericsson.jenkins.plugins.bfa.model.ScannerJobProperty'( plugin: 'build-failure-analyzer@1.13.0'){
        doNotScan(false)
      }
    }
    'jdk' ('(Default)')
    label(aJob.server)
    quietPeriod(0)
    scm{
      git{
        remote{
          url("git@github.aetna.com:${aJob.gitOrg}/${aJob.jobName}.git")
          credentials('f4953df8-6f5d-4843-a332-c86ff1208f76')
        }
        branches("origin/${aJob.jobName}_Path*")
        extensions{cleanAfterCheckout()}
        configure {
            it / gitTool("windows_32_git")
        }
      }
    }
    triggers{ scm('') }
    
    steps {
        batchFile ("""@echo OFF
reg Query \"HKLM\\Hardware\\Description\\System\\CentralProcessor\\0\" | find /i "x86" > NUL && echo OS=32BIT >> os_version.properties || echo OS_VERSION=64BIT >> os_version.properties
""")
        environmentVariables {
            propertiesFile('os_version.properties')
        }
        batchFile ('''IF %OS_VERSION%==32BIT (
   set PROGRAM_FILES_DIR=Program Files
) ELSE (
   set PROGRAM_FILES_DIR=Program Files (x86)
)
PATH=c:\\%PROGRAM_FILES_DIR%\\Cygwin\\bin;%PATH%''')
        batchFile ('''curl -s -o /dev/null -w '%%{http_code}' https://sonarqube.aetna.com/sessions/new > STATUS_CODE.txt
set /p STATUS_CODE=<STATUS_CODE.txt
del STATUS_CODE.txt
IF "%STATUS_CODE%"=="200" (
   echo SONAR_HEALTH_CHECK=true >> env.properties
) ELSE (
    echo SONAR_HEALTH_CHECK=false >> env.properties
)''')
        environmentVariables {
            propertiesFile('env.properties')
        }
        batchFile('''ratlperl //aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/IIB_build.pl .
ratlperl //aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/getPath.pl %GIT_BRANCH% > ./runtime.devops.properties
ratlperl //aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/pathExtendedProject.pl %GIT_URL% %GIT_BRANCH% >> runtime.devops.properties''')
        environmentVariables {
          propertiesFile('${WORKSPACE}/JNK.properties')
    }
        environmentVariables {
          propertiesFile('${WORKSPACE}/runtime.devops.properties')
    }
        batchFile("""if not exist "//aetnas90/build/cam/Jenkins/data/GIT/${buildType}/%DEVOPS_PATH_EXTENDED_PROJECT%.properties" echo DEVOPS_BRANCH_BUILD_NUMBER=1 > "//aetnas90/build/cam/Jenkins/data/GIT/${buildType}/%DEVOPS_PATH_EXTENDED_PROJECT%.properties" """)
        environmentVariables { propertiesFile('\\\\aetnas90\\build\\cam\\Jenkins\\data\\GIT\\ODM\\${DEVOPS_PATH_EXTENDED_PROJECT}.properties')
                               env('UCD_SNAPSHOT', '${DEVOPS_PATH_EXTENDED_PROJECT}_${DEVOPS_BRANCH_BUILD_NUMBER}') 
        }
        environmentVariables {
            envs( JAVA_HOME: "C:\\Program Files\\Java\\jdk17")
        }
        ant{
          target('all')
        }
        batchFile("""ratlperl "//aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/makeDeploy.pl" "//aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/OdmDeployTemplate.xml" enterpriseAppName=${nameLessOdm} recipient=${emailList} >%WORKSPACE%\\dist\\${aJob.jobName}_deploy.xml""")
        if ( ! aJob.disableSonarqube )
        {
            conditionalSteps {
                condition {
                    booleanCondition ('${ENV,var="SONAR_HEALTH_CHECK"}')
                }
                runner('Run')
            }
        }
    if ( ! aJob.disableSonarqube )
//    if ( '' )
    {
        configure { 
            it / 'builders' / 'org.jenkinsci.plugins.conditionalbuildstep.ConditionalBuilder' / 'conditionalbuilders' << 'hudson.plugins.sonar.SonarRunnerBuilder'(plugin: 'sonar@2.2.1'){
                project()
                installationName("SonarQubeProd")
                sonarScannerName("Win_Sonar_Runner_Build_Server")
                properties('''sonar.projectKey=${DEVOPS_PATH_EXTENDED_PROJECT}
sonar.projectName=${DEVOPS_PATH_EXTENDED_PROJECT}  
sonar.projectVersion=$BUILD_NUMBER
sonar.language=java
sonar.sources=.
sonar.sourceEncoding=UTF-8
sonar.login=${SONARQUBE_SCANNER_TOKEN}''')
                javaOpts()
                delegate.jdk('Windows JDK 1.8')
                task()
            }
        }
    }
    publishers {
        extendedEmail {
            recipientList(emailList)
            defaultSubject('Build Report for ${DEVOPS_PATH_EXTENDED_PROJECT} - Build # ${DEVOPS_BRANCH_BUILD_NUMBER} - $BUILD_STATUS!')
            contentType('text/html')
            saveToWorkspace()
            defaultContent(emailSuccessContent)
            triggers {
               success {
                  attachBuildLog()
                  compressBuildLog()
                  sendTo {
                      recipientList()
                  }
              }
               failure {
                  attachBuildLog()
                  compressBuildLog()
                  subject('**FAILED BUILD**  for ${DEVOPS_PATH_EXTENDED_PROJECT} - Build # ${DEVOPS_BRANCH_BUILD_NUMBER} - $BUILD_STATUS!')
                  content(emailFailureContent)
                  sendTo {
                      recipientList()
                  }
              }
               aborted {
                  attachBuildLog()
                  compressBuildLog()
                  subject('**ABORTED BUILD**  for ${DEVOPS_PATH_EXTENDED_PROJECT} - Build # ${DEVOPS_BRANCH_BUILD_NUMBER} - $BUILD_STATUS!')
                  content(emailFailureContent)
                  sendTo {
                      recipientList()
                  }
              }
            }
        }
        postBuildScripts {
          steps {
            batchFile("""ratlperl "//aetnas90/build/cam/Jenkins/scripts/uploadToUdeploy.pl" --user s060758 --password %s060758% --component ${aJob.jobName} --version ${aJob.jobName}_%BUILD_NUMBER% --snapshot %UCD_SNAPSHOT% --include 'dist/*.*' --quiet --application ${aJob.jobName} --version-properties %WORKSPACE%\\exec_group.properties %WORKSPACE%
ratlperl "//aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/runUdeployApplicationProcess.pl" --user s060758 --password %s060758% --snapshot %UCD_SNAPSHOT% --application ${aJob.jobName} --application-process Deploy_ODM_App --environment DEV%DEVOPS_PATH%
ratlperl "//aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/addOneToFile.pl" --environment-variable DEVOPS_BRANCH_BUILD_NUMBER "//aetnas90/build/cam/Jenkins/data/GIT/${buildType}/%DEVOPS_PATH_EXTENDED_PROJECT%.properties"
""")
          }
          markBuildUnstable(false)
          onlyIfBuildFails(false)
          onlyIfBuildSucceeds(true)
        }
    }
    wrappers {
      timestamps()
      maskPasswords()
      injectPasswords{
         injectGlobalPasswords(true)
         maskPasswordParameters(true)
        
      }
    }
  }
}
