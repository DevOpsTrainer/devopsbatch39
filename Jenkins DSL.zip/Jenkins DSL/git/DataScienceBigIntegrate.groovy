import groovy.json.JsonSlurper 
String defaultEmail = 'cc:HuttonJ@aetna.com'
@groovy.transform.Canonical class job { 
  String jobName, folder ='/GIT/PDS/BigIntegrate', server ='xcamjbem1p.p1', gitOrg, recipientList=''
} 
hudson.FilePath workspace = hudson.model.Executor.currentExecutor().getCurrentWorkspace()

def dataFile = "${workspace}/jenkins/groovy.dsl/git/data/DataScienceBigIntegrate.txt"
println("Data file is: ${dataFile}")
new File(dataFile).eachLine{ line ->
def aJob = job.newInstance(new JsonSlurper().parseText(line))
  println "Making job: ${aJob.folder}/${aJob.jobName}"
  String emailList = aJob.recipientList ? "${aJob.recipientList},${defaultEmail}" : defaultEmail
  String emailSuccessContent="""<!DOCTYPE html>
<html>
<body>


<p>Dear User,</p>

<p>Please find the build details</p>
<table style="width:100%">

<table border="1" bgcolor="#EFFBFB">

  <tr>
    <td><b>Job Name</b></td>
    <td>\$JOB_NAME</td>    
  </tr>
  <tr>
    <td><b>Build Number</b></td>
    <td>\$BUILD_NUMBER</td>    
  </tr>
  <tr>
    <td><b>Git repository URL</b></td>
    <td>\$GIT_URL</td>    
  </tr>
  <tr>
    <td><b>Git branch</b></td>
    <td>\$GIT_BRANCH</td>    
  </tr>
  <tr>
    <td><b>Committed by</b></td>
    <td>\${CHANGES,format="%a"}</td>    
  </tr>
  <tr>
    <td><b>Commit ID</b></td>
    <td>\${CHANGES,format="%r"}</td>    
  </tr>
  <tr>
    <td><b>Changes</b></td>
    <td>\${CHANGES,showPaths=true,format="%p"}</td>    
  </tr>
  <tr>
    <td><b>Commit Message</b></td>
    <td>\${CHANGES,format="&#8220;<em>%m</em>&#8221"}</td>    
  </tr>
  <tr>
    <td><b>Build Date & Time<b></td>
    <td>\$BUILD_TIMESTAMP</td>    
  </tr>
  <tr>
    <td><b>Build Status</b></td>
    <td>\$BUILD_STATUS</td>    
  </tr>
  <tr>
    <td><b>Build URL</b></td>
    <td>\$BUILD_URL</td>    
  </tr>
</table>
<BR><BR>
Thanks,<BR><BR>
CAM nonMainframe Tool support<BR>
</body>
</html>"""

  job("${aJob.folder}/${aJob.jobName}") { 
    description("""Made by Job DSL plugin.
Do not edit by hand.
Made by jenkins/groovy.dsl/git/DataScienceBigIntegrate.groovy""")
    logRotator(-1, 20)
    configure{
      it / 'properties' << 'com.sonyericsson.jenkins.plugins.bfa.model.ScannerJobProperty'( plugin: 'build-failure-analyzer@1.13.0'){
        doNotScan(false)
      }
    }
    parameters {
      stringParam('BRANCH', "*/${aJob.jobName}_Path*", 'Clear the value if promoting manually and input the name of the branch to build.')
    }
    'jdk' ('(Default)')
    label(aJob.server)
    quietPeriod(0)
    scm{
      git{
        remote{
          url("git@github.aetna.com:${aJob.gitOrg}/${aJob.jobName}.git")
          credentials('f4953df8-6f5d-4843-a332-c86ff1208f76')
        }
        branches('*/master','${BRANCH}')
        extensions{cleanAfterCheckout()}
      }
    }
    triggers{ scm('') }
     wrappers {
        maskPasswords() //This pulls in global passwords
        injectPasswords{
          injectGlobalPasswords()
          maskPasswordParameters()
        }
        timestamps()
    }
    steps{
        shell('''//aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/getPath.pl $GIT_BRANCH > ./runtime.devops.properties
//aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/pathExtendedProject.pl ${GIT_URL} ${GIT_BRANCH} >> runtime.devops.properties''')
      environmentVariables{
        propertiesFile('runtime.devops.properties')
            env('UCD_SNAPSHOT', '${DEVOPS_SHORT_PROJECT}-${DEVOPS_SHORT_BRANCH}_${BUILD_NUMBER}') 
      }
      shell("""echo "ProjectName=${aJob.jobName}" > version.properties
echo "BuildURL=\${BUILD_URL}" >> version.properties
echo "BuildNumber=\${BUILD_NUMBER}" >> version.properties
echo "project=${aJob.jobName}" >> version.properties""")
    }
    publishers {
        extendedEmail {
            recipientList(emailList)
            defaultSubject('Build Report for ${DEVOPS_PATH_EXTENDED_PROJECT} - Build # ${DEVOPS_BRANCH_BUILD_NUMBER} - $BUILD_STATUS!')
            contentType('text/html')
            saveToWorkspace()
            defaultContent(emailSuccessContent)
            triggers {
               success {
                  sendTo {
                      recipientList()
                  }
               }
               failure {
                  subject('**FAILED BUILD** for ${DEVOPS_PATH_EXTENDED_PROJECT} - Build # ${DEVOPS_BRANCH_BUILD_NUMBER} - $BUILD_STATUS!')
                  sendTo {
                      recipientList()
                  }
               }
            }
        }
        postBuildScripts {
          steps {
            shell("""//aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/uploadToUdeploy.pl --user s060758 --password "\$s060758" --component ${aJob.jobName} --version \${UCD_SNAPSHOT} --snapshot \${UCD_SNAPSHOT} --include '**/*' --exclude '**/.git/**'  --quiet --application ${aJob.jobName} --version-properties \${WORKSPACE}/version.properties \${WORKSPACE}
//aetnas90/build/cam/ccase_views/s015457_cam_jenkins_rel/v/cam_config/jenkins/perl/runUdeployApplicationProcess.pl --user s060758 --password \${s060758} --snapshot \${UCD_SNAPSHOT} --application ${aJob.jobName} --application-process Deploy_BigIntegrate --environment DEV""")
          }
          markBuildUnstable(false)
          onlyIfBuildFails(false)
          onlyIfBuildSucceeds(true)
        }
      }

  }
}
